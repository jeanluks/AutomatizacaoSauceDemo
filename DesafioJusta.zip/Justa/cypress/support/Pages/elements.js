export const ELEMENTS = {
    username: '[data-test=username]',
    password: '[data-test=password]',
    loginButton: '[data-test=login-button]',
    error: '[data-test=error]',
    title: '.title',
    addTShirt: '[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]',
    cartNumber: '.shopping_cart_badge',
    cartButton: '.shopping_cart_link',
    inventory: '.inventory_item_name',
    checkoutButton: '[data-test=checkout]',
    firstName: '[data-test=firstName]',
    lastName:'[data-test=lastName]',
    postalCode: '[data-test=postalCode]',
    continueButton: '[data-test=continue]',
    finishButton: '[data-test=finish]',
    thankYou: '.complete-header',
    goHome: '[data-test=back-to-products]',
    backpack: '[data-test=add-to-cart-sauce-labs-backpack]',
    comboBox: '[data-test=product_sort_container]',
    onesie: '[data-test=add-to-cart-sauce-labs-onesie]',
    bike: '[data-test=add-to-cart-sauce-labs-bike-light]'
}

export default ELEMENTS;