const elem = require('./elements').ELEMENTS;

class login{

    AcessarPagina(){
        cy.visit('https://www.saucedemo.com/') 
    }

    LoginVerde(){
        cy.get(elem.username).type('standard_user')
        cy.get(elem.password).type('secret_sauce')
        cy.get(elem.loginButton).click()
        cy.get(elem.title).should('contain', 'Products') // Confirmação de que estou na home
    }

    SenhaIncorreta(){
    cy.get(elem.username).type('standard_user')
    cy.get(elem.password).type('teste')
    cy.get(elem.loginButton).click()
    cy.get(elem.error).should('contain', 'Username and password do not match any user in this service') // Confirmação de que recebi o erro
    }

    UsernameIncorreto(){
    cy.get(elem.username).type('teste')
    cy.get(elem.password).type('secret_sauce')
    cy.get(elem.loginButton).click()
    cy.get(elem.error).should('contain', 'Username and password do not match any user in this service') // Confirmação de que recebi o erro
    }

    UsernameVazio(){
    cy.get(elem.password).type('secret_sauce')
    cy.get(elem.loginButton).click()
    cy.get(elem.error).should('contain', 'Username is required') // Confirmação de que recebi o erro
    }

    SenhaVazia(){
    cy.get(elem.username).type('standard_user')
    cy.get(elem.loginButton).click()
    cy.get(elem.error).should('contain', 'Password is required') // Confirmação de que recebi o erro
    }

    LoginLocked(){
      cy.get(elem.username).type('locked_out_user')
      cy.get(elem.password).type('secret_sauce')
      cy.get(elem.loginButton).click()
      cy.get(elem.error).should('contain', 'Sorry, this user has been locked out.') // Confirmação de que recebi o erro
    }

    LoginProblemUser(){
      cy.get(elem.username).type('problem_user')
      cy.get(elem.password).type('secret_sauce')
      cy.get(elem.loginButton).click()
      cy.get(elem.title).should('contain', 'Products') // Confirmação de que estou na home
    }

    LoginPerformance(){
      cy.get(elem.username).type('performance_glitch_user')
      cy.get(elem.password).type('secret_sauce')
      cy.get(elem.loginButton).click()
      cy.get(elem.title).should('contain', 'Products') // Confirmação de que estou na home
    }

    CompraCamisaVer(){
      cy.get(elem.addTShirt).click()
      cy.get(elem.cartNumber).should('contain', '1')
      cy.get(elem.cartButton).click()
      cy.get(elem.title).should('contain', 'Your Cart')
      cy.get(elem.inventory).should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get(elem.checkoutButton).click()
      cy.get(elem.firstName).type('Jean')
      cy.get(elem.lastName).type('Lucas')
      cy.get(elem.postalCode).type('000000')
      cy.get(elem.continueButton).click()
      cy.get(elem.title).should('contain', 'Checkout: Overview')
      cy.get(elem.inventory).should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get(elem.finishButton).click()
      cy.get(elem.title).should('contain', 'Checkout: Complete!')
      cy.get(elem.thankYou).should('contain', 'Thank you for your order!')
      cy.get(elem.goHome).click()
      cy.get(elem.title).should('contain', 'Products')
    }

    ComprarBolsa(){
        cy.get(elem.backpack).click()
        cy.get(elem.cartNumber).should('contain', '1')
        cy.get(elem.cartButton).click()
        cy.get(elem.title).should('contain', 'Your Cart')
        cy.get(elem.inventory).should('contain', 'Sauce Labs Backpack')
        cy.get(elem.checkoutButton).click()
        cy.get(elem.firstName).type('Jean')
        cy.get(elem.lastName).type('Lucas')
        cy.get(elem.postalCode).type('000000')
        cy.get(elem.continueButton).click()
        cy.get(elem.title).should('contain', 'Checkout: Overview')
        cy.get(elem.inventory).should('contain', 'Sauce Labs Backpack')
        cy.get(elem.finishButton).click()
        cy.get(elem.title).should('contain', 'Checkout: Complete!')
        cy.get(elem.thankYou).should('contain', 'Thank you for your order!')
        cy.get(elem.goHome).click()
        cy.get(elem.title).should('contain', 'Products')
    }

    CamisaBolsa(){
        cy.get(elem.addTShirt).click()
        cy.get(elem.cartNumber).should('contain', '1')
        cy.get(elem.backpack).click()
        cy.get(elem.cartNumber).should('contain', '2')
        cy.get(elem.cartButton).click()
        cy.get(elem.title).should('contain', 'Your Cart')
        cy.get(elem.inventory).should('contain', 'Test.allTheThings() T-Shirt (Red)')
        cy.get(elem.inventory).should('contain', 'Sauce Labs Backpack')
        cy.get(elem.checkoutButton).click()
        cy.get(elem.firstName).type('Jean')
        cy.get(elem.lastName).type('Lucas')
        cy.get(elem.postalCode).type('000000')
        cy.get(elem.continueButton).click()
        cy.get(elem.title).should('contain', 'Checkout: Overview')
        cy.get(elem.inventory).should('contain', 'Test.allTheThings() T-Shirt (Red)')
        cy.get(elem.inventory).should('contain', 'Sauce Labs Backpack')
        cy.get(elem.finishButton).click()
        cy.get(elem.title).should('contain', 'Checkout: Complete!')
        cy.get(elem.thankYou).should('contain', 'Thank you for your order!')
        cy.get(elem.goHome).click()
        cy.get(elem.title).should('contain', 'Products')
    }

    OrdenarMaiorMenor(){
        cy.get(elem.comboBox).select('Price (low to high)')
        cy.get(elem.comboBox).should('have.value', 'lohi')
    }

    OnesieBike(){
      cy.get(elem.onesie).click()
      cy.get(elem.cartNumber).should('contain', '1')
      cy.get(elem.bike).click()
      cy.get(elem.cartButton).should('contain', '2')
      cy.get(elem.cartButton).click()
      cy.get(elem.title).should('contain', 'Your Cart')
      cy.get(elem.inventory).should('contain', 'Sauce Labs Onesie')
      cy.get(elem.inventory).should('contain', 'Sauce Labs Bike Light')
      cy.get(elem.checkoutButton).click()
      cy.get(elem.firstName).type('Jean')
      cy.get(elem.lastName).type('Lucas')
      cy.get(elem.postalCode).type('000000')
      cy.get(elem.continueButton).click()
      cy.get(elem.title).should('contain', 'Checkout: Overview')
      cy.get(elem.inventory).should('contain', 'Sauce Labs Onesie')
      cy.get(elem.inventory).should('contain', 'Sauce Labs Bike Light')
      cy.get(elem.finishButton).click()
      cy.get(elem.title).should('contain', 'Checkout: Complete!')
      cy.get(elem.thankYou).should('contain', 'Thank you for your order!')
      cy.get(elem.goHome).click()
      cy.get(elem.title).should('contain', 'Products')
    }

    CompraSemProduto(){
        cy.get(elem.cartButton).click()
        cy.get(elem.title).should('contain', 'Your Cart')
        cy.get(elem.checkoutButton).click()
        cy.get(elem.firstName).type('Jean')
        cy.get(elem.lastName).type('Lucas')
        cy.get(elem.postalCode).type('000000')
        cy.get(elem.continueButton).click()
        cy.get(elem.title).should('contain', 'Checkout: Overview')
        cy.get(elem.finishButton).click()
        cy.get(elem.title).should('contain', 'Checkout: Complete!')
        cy.get(elem.thankYou).should('contain', 'Thank you for your order!')
        cy.get(elem.goHome).click()
        cy.get(elem.title).should('contain', 'Products')
    }

    LoginProblemUser(){
      cy.get(elem.username).type('problem_user')
      cy.get(elem.password).type('secret_sauce')
      cy.get(elem.loginButton).click()
      cy.get(elem.title).should('contain', 'Products') // Confirmação de que estou na home
    }

    LoginPerformanceUser(){
        cy.get(elem.username).type('performance_glitch_user')
        cy.get(elem.password).type('secret_sauce')
        cy.get(elem.loginButton).click()
        cy.get(elem.title).should('contain', 'Products') // Confirmação de que estou na home
    }


}
export default new login();