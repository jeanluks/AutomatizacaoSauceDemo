describe('Visitar pagina do saucedemo e fazer testes de login', function() {

  describe('Caminho verde', function(){

    before(function(){
      cy.visit('https://www.saucedemo.com/')
    })

    it('Login, caminho verde - Username e senha valido', function() {

      cy.get('[data-test="username"]').type('standard_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })
  })

  describe('Caminho vermelho', function(){

  beforeEach(function (){
    cy.visit('https://www.saucedemo.com/')
  })

  it('Login, caminho vermelho - Username valido e senha incorreta', function(){

    cy.get('[data-test="username"]').type('standard_user')
    cy.get('[data-test="password"]').type('teste')
    cy.get('[data-test="login-button"]').click()
    cy.get('[data-test="error"]').should('contain', 'Username and password do not match any user in this service') // Confirmação de que recebi o erro
  })

  it('Login, caminho vermelho - Username invalido e senha valida', function(){

    cy.get('[data-test="username"]').type('teste')
    cy.get('[data-test="password"]').type('secret_sauce')
    cy.get('[data-test="login-button"]').click()
    cy.get('[data-test="error"]').should('contain', 'Username and password do not match any user in this service') // Confirmação de que recebi o erro
  })

  it('Login, caminho vermelho - Campo de username vazio e senha valida', function(){

    cy.get('[data-test="password"]').type('secret_sauce')
    cy.get('[data-test="login-button"]').click()
    cy.get('[data-test="error"]').should('contain', 'Username is required') // Confirmação de que recebi o erro
  })

  it('Login, caminho vermelho - Campo de username valido e senha vazia', function(){

    cy.get('[data-test="username"]').type('standard_user')
    cy.get('[data-test="login-button"]').click()
    cy.get('[data-test="error"]').should('contain', 'Password is required') // Confirmação de que recebi o erro
  })
  })

  describe('Testar login com todas as combinações de username e password', function(){

    beforeEach(function (){
      cy.visit('https://www.saucedemo.com/')
    })

    it('Login, standard_user + secret_sauce', function() {

      cy.get('[data-test="username"]').type('standard_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })

    it('Login, locked_out_user + secret_sauce', function() {

      cy.get('[data-test="username"]').type('locked_out_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('[data-test="error"]').should('contain', 'Sorry, this user has been locked out.') // Confirmação de que recebi o erro
    })

    it('Login, problem_user + secret_sauce', function() {

      cy.get('[data-test="username"]').type('problem_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })

    it('Login, performance_glitch_user + secret_sauce', function() {

      cy.get('[data-test="username"]').type('performance_glitch_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })
  })
})

describe('Teste de compra', function(){

  describe('Compras com o standard_user', function(){

    beforeEach('Login, caminho verde - Username e senha valido', function(){

      cy.visit('https://www.saucedemo.com/')
      cy.get('[data-test="username"]').type('standard_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })

    it('Comprar camisa vermelha', function(){

      cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').click()
      cy.get('.shopping_cart_badge').should('contain', '1')
      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
      cy.get('.title').should('contain', 'Products')
    })

    it('Comprar bolsa', function(){

      cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click()
      cy.get('.shopping_cart_badge').should('contain', '1')
      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Backpack')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Backpack')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
    })

    it('Comprar camisa vermelha e bolsa', function(){

      cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').click()
      cy.get('.shopping_cart_badge').should('contain', '1')
      cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click()
      cy.get('.shopping_cart_badge').should('contain', '2')
      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Backpack')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Backpack')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
      cy.get('.title').should('contain', 'Products')
    })

    it('Ordenar os valores do menor para o maior e comprar os 2 produtos menores', function(){

      cy.get('[data-test="product_sort_container"]').select('Price (low to high)')
      cy.get('[data-test="product_sort_container"]').should('have.value', 'lohi')
      cy.get('[data-test="add-to-cart-sauce-labs-onesie"]').click()
      cy.get('.shopping_cart_badge').should('contain', '1')
      cy.get('[data-test="add-to-cart-sauce-labs-bike-light"]').click()
      cy.get('.shopping_cart_badge').should('contain', '2')
      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Onesie')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Bike Light')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Onesie')
      cy.get('.inventory_item_name').should('contain', 'Sauce Labs Bike Light')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
      cy.get('.title').should('contain', 'Products')
    })

    it('Realizar compra sem nada no carrinho', function(){ //BUG ENCONTRADO

      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
      cy.get('.title').should('contain', 'Products')
    })

  })

  describe('Compras com problem_user', function(){ //BUG ENCONTRADO

    beforeEach('Login, caminho verde - Username e senha valido', function() {

      cy.visit('https://www.saucedemo.com/')
      cy.get('[data-test="username"]').type('problem_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })

    it('Comprar camisa vermelha', function(){

      cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').click()
      cy.get('.shopping_cart_badge').should('contain', '1')
      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
      cy.get('.title').should('contain', 'Products')
    })
  })

  describe('Compras com performance_glitch_user', function(){

    beforeEach('Login, caminho verde - Username e senha valido', function() {

      cy.visit('https://www.saucedemo.com/')
      cy.get('[data-test="username"]').type('performance_glitch_user')
      cy.get('[data-test="password"]').type('secret_sauce')
      cy.get('[data-test="login-button"]').click()
      cy.get('.title').should('contain', 'Products') // Confirmação de que estou na home
    })

    it('Comprar camisa vermelha', function(){

      cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]').click()
      cy.get('.shopping_cart_badge').should('contain', '1')
      cy.get('.shopping_cart_link').click()
      cy.get('.title').should('contain', 'Your Cart')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('[data-test="checkout"]').click()
      cy.get('[data-test="firstName"]').type('Jean')
      cy.get('[data-test="lastName"]').type('Lucas')
      cy.get('[data-test="postalCode"]').type('000000')
      cy.get('[data-test="continue"]').click()
      cy.get('.title').should('contain', 'Checkout: Overview')
      cy.get('.inventory_item_name').should('contain', 'Test.allTheThings() T-Shirt (Red)')
      cy.get('[data-test="finish"]').click()
      cy.get('.title').should('contain', 'Checkout: Complete!')
      cy.get('.complete-header').should('contain', 'Thank you for your order!')
      cy.get('[data-test="back-to-products"]').click()
      cy.get('.title').should('contain', 'Products')
    })
  })
})