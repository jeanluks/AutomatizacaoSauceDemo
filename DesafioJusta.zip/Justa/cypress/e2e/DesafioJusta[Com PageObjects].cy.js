import login from '../support/Pages/index'

describe('Visitar pagina do saucedemo e fazer testes de login', function(){

  describe('Caminho verde', function(){

     before(function(){
      login.AcessarPagina()
    })

    it('Login, caminho verde - Username e senha valido', function(){
    login.LoginVerde()
    })
  })

  describe('Caminho vermelho', function(){

    beforeEach(function(){
        login.AcessarPagina()
      })

      it('Login, caminho vermelho - Username valido e senha incorreta', function(){
        login.SenhaIncorreta()
      })

      it('Login, caminho vermelho - Username invalido e senha valida', function(){
        login.UsernameIncorreto()
      })

      it('Login, caminho vermelho - Campo de username vazio e senha valida', function(){
        login.UsernameVazio()
      })

      it('Login, caminho vermelho - Campo de username valido e senha vazia', function(){
        login.SenhaVazia()
      })
  })

  describe('Testar login com todas as combinações de username e password', function(){

    beforeEach(function(){
        login.AcessarPagina()
    })

    it('Login, standard_user + secret_sauce', function(){
        login.LoginVerde()
    })

    it('Login, locked_out_user + secret_sauce', function(){
        login.LoginLocked()
    })

    it('Login, problem_user + secret_sauce', function(){
        login.LoginProblemUser()
    })

    it('Login, performance_glitch_user + secret_sauce', function(){
        login.LoginPerformance()
    })

  })
})

describe('Teste de compra', function(){

    describe('Compras com o standard_user', function(){

        beforeEach('Login, caminho verde - Username e senha valido', function(){
            login.AcessarPagina()
            login.LoginVerde()
        })

        it('Comprar camisa vermelha', function(){
            login.CompraCamisaVer();
        })

        it('Comprar bolsa', function(){
            login.ComprarBolsa()
        })

        it('Comprar camisa vermelha e bolsa', function(){
            login.CamisaBolsa()
        })

        it('Ordenar os valores do menor para o maior e comprar os 2 produtos menores', function(){
            login.OrdenarMaiorMenor()
            login.OnesieBike()
        })

        it('Realizar compra sem nada no carrinho', function(){ //BUG ENCONTRADO
            login.CompraSemProduto()
        })
    })

    describe('Compras com problem_user', function(){ //BUG ENCONTRADO

        beforeEach('Login, caminho verde - Username e senha valido', function(){
            login.AcessarPagina()
            login.LoginProblemUser()
        })

        it('Comprar camisa vermelha', function(){
            login.CompraCamisaVer()
        })
    })

    describe('Compras com performance_glitch_user', function(){

        beforeEach('Login, caminho verde - Username e senha valido', function(){
            login.AcessarPagina()
            login.LoginPerformanceUser()
        })

        it('Comprar camisa vermelha', function(){
            login.CompraCamisaVer()
        })
    })
})